# Permission to Relicense under MPLv2 or any other OSI approved license chosen by the current ZeroMQ BDFL

This is a statement by Juha Reunanen, Tomaattinen Ltd, and Outotec (Finland) Oy
that grants permission to relicense their copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2) or any other 
Open Source Initiative approved license chosen by the current ZeroMQ 
BDFL (Benevolent Dictator for Life).

A portion of the commits made by the GitHub handle "reunanen", with
commit author "Juha Reunanen <juha.reunanen@tomaattinen.com>", are copyright of Juha Reunanen.
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

Juha Reunanen
2017/04/01
